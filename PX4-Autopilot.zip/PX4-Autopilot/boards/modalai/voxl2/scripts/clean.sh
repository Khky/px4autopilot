#!/bin/bash

# Clean out the build artifacts
# source /home/build-env.sh
# make clean

# This gets rid of everything and starts fresh
sudo rm -fR build
