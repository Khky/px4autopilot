#!/bin/bash

echo "*** Starting qurt slpi build ***"

source /home/build-env.sh

make modalai_voxl2-slpi

echo "*** End of qurt slpi build ***"
